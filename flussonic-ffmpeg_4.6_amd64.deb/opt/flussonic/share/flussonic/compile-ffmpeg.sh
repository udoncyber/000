#!/bin/bash

# Do this in vagrant:
#
#
# Vagrant::Config.run do |config|
#   config.vm.define :debian2 do |conf|
#     conf.vm.box = "debian2"
#     conf.vm.box_url = "http://f.willianfernandes.com.br/vagrant-boxes/DebianSqueeze64.box"
#     conf.vm.share_folder "v-apt", "/var/cache/apt/archives", ".vagrant_aptcache"
#   end
# end


set -e
set -x


export LANG=C

. /root/env.sh

OUTDIR=/output
mkdir -p $OUTDIR


if [ -n "${CCACHE_DIR:-}" ]; then
    echo Activate ccache
    export PATH=/usr/lib/ccache:$PATH
fi


export PATH=/opt/flussonic-build/bin:$PATH



if [ "$ARCH" != "amd64" ]; then
  NVENC=0
  DISABLE_OPENH264=1
  DISABLE_X265=1
  DISABLE_V4L2=1
fi



if [ ! -z "$CROSSCOMPILE" ]; then
  FFARCH=$ARCH
  if [ "$ARCH" = arm64 ]; then
    FFARCH=aarch64
  fi
  FFMPEGFLAGS="--enable-cross-compile --disable-vfp --disable-neon --disable-asm --arch=${FFARCH} --target-os=linux --cross-prefix=${CROSSPREFIX}-"
fi





if [ ! -f /opt/flussonic/lib/libswscale.so ] ; then
  #if [ ! -f ffmpeg-${SRC_VERSION}/ffmpeg ] ; then
    tar zxf /root/ffmpeg-${SRC_VERSION}.tar.gz
    cd ffmpeg-${SRC_VERSION}

    patch -p1 < /root/ffmpeg-disable-error-ue-message.patch                   #! disable Invalid UE globe
    patch -p1 < /root/ffmpeg-disable-nonblocking-avformat.patch
    if [ "$SPLITGPL" = 1 ] ; then
      cp /root/avcodec_gpl.c fftools/
      cp /root/avcodec_gpl.h fftools/
      patch -p1 < /root/ffmpeg-3.4.1.patch
    fi

    if [ $DISABLE_X265 = 0 ]; then
        CONF_X265="--enable-libx265"
    else
        CONF_X265=""
    fi

    CONFOPTS=""
    [ $AACPLUS          = 1 ] && CONFOPTS="$CONFOPTS --enable-libaacplus"
    [ $FDKAAC           = 1 ] && CONFOPTS="$CONFOPTS --enable-libfdk-aac"
    [ $DISABLE_V4L2     = 0 ] && CONFOPTS="$CONFOPTS --enable-libv4l2"
    [ $SPLITGPL         = 0 ] && CONFOPTS="$CONFOPTS --enable-gpl --enable-libx264 $CONF_X265"
    [ $NVENC            = 1 ] && CONFOPTS="$CONFOPTS --enable-nvenc"
    [ $DISABLE_OPENH264 = 0 ] && CONFOPTS="$CONFOPTS --enable-libopenh264"
    [ ! $DISABLE_OPUS   = 1 ] && CONFOPTS="$CONFOPTS --enable-libopus"

    if [ -z "$CROSSCOMPILE" ]; then
      CONFOPT="$CONFOPTS --enable-libmp3lame --enable-decoder=png --enable-encoder=png"
    fi
    CONFOPTS="$CONFOPTS --enable-libvpx"
    # echo $CONFOPTS

    mkdir -p /opt/flussonic

    #--enable-libx265 \
    #--enable-librtmp \
    #--enable-libfreetype --enable-filter=drawtext \

    mkdir -p /opt/flussonic/lib
    PKG_CONFIG_PATH="/opt/flussonic/lib/pkgconfig/:/opt/flussonic-build/lib/pkgconfig/" \
    ./configure $FFMPEGFLAGS --pkg-config-flags="--static" \
      --enable-nonfree --disable-static --enable-shared --enable-pic  \
       $CONFOPTS \
      --disable-decoder=snow --disable-encoder=snow \
      --prefix=/opt/flussonic \
      --extra-ldflags="-L/opt/flussonic-build/lib -Wl,-rpath /opt/flussonic/lib -L/opt/flussonic/lib" \
      --extra-cflags="-I/opt/flussonic-build/include -I/opt/flussonic/include"
    make -j5 V=yay
    # --enable-libspeex --enable-libvpx 
    

    #cd ..
  #fi
  #cd ffmpeg-${SRC_VERSION}
  make install
  rm -rf /opt/flussonic/share/man
  rm -rf /opt/flussonic/share/ffmpeg/examples
  cd ..

fi

if [ "$SPLITGPL" = 1 ] ; then

if [ ! -f /opt/flussonic/lib/libff_x264.so.1 ]; then
  # X264
  echo "GCC libff_x264.so"
  cd ffmpeg-${SRC_VERSION}

  #make clean

  #sed -i -e 's/_DECODER 1/_DECODER 0/' -e 's/_DEMUXER 1/_DEMUXER 0/' -e 's/_ENCODER 1/_ENCODER 0/' -e 's/_FILTER 1/_FILTER 0/' -e 's/_PROTOCOL 1/_PROTOCOL 0/' -e 's/_PARSER 1/_PARSER 0/' -e 's/_INDEV 1/_INDEV 0/' -e 's/_MUXER 1/_MUXER 0/' -e 's/_OUTDEV 1/_OUTDEV 0/' config.h
  #sed -i -e 's/_DECODER 1/_DECODER 0/' -e 's/_DEMUXER 1/_DEMUXER 0/' -e 's/_ENCODER 1/_ENCODER 0/' -e 's/_FILTER 1/_FILTER 0/' -e 's/_PROTOCOL 1/_PROTOCOL 0/' -e 's/_PARSER 1/_PARSER 0/' -e 's/_INDEV 1/_INDEV 0/' -e 's/_MUXER 1/_MUXER 0/' -e 's/_OUTDEV 1/_OUTDEV 0/' config.asm
  
  sed -i -e 's/CONFIG_LIBX264 0/CONFIG_LIBX264 1/' \
         -e 's/CONFIG_LIBX265 0/CONFIG_LIBX265 1/' \
         -e 's/CONFIG_LIBX264_ENCODER 0/CONFIG_LIBX264_ENCODER 1/' \
         -e 's/CONFIG_LIBX265_ENCODER 0/CONFIG_LIBX265_ENCODER 1/' \
         -e 's/CONFIG_SNOW_DECODER 1/CONFIG_SNOW_DECODER 0/' \
         -e 's/CONFIG_SNOW_ENCODER 1/CONFIG_SNOW_ENCODER 0/' config.h  

  X264_CFLAGS="-shared -I. -I./ -D_ISOC99_SOURCE -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE -D_POSIX_C_SOURCE=200112 \
-D_XOPEN_SOURCE=600 -DPIC -DZLIB_CONST -DHAVE_AV_CONFIG_H -I/opt/flussonic-build/include \
-std=c99 -fomit-frame-pointer -fPIC -O3"
  X264_LDFLAGS="-Wl,-soname,libff_x264.so.1 \
-L/opt/flussonic-build/lib -L/opt/flussonic/lib -Wl,-rpath /opt/flussonic/lib -Wl,-s -lavcodec -lavutil -lpthread -lm"

  X264_OBJS="libavcodec/utils.o \
libavcodec/encode.o \
libavcodec/pthread_frame.o \
libavcodec/pthread.o \
libavcodec/pthread_slice.o \
libavcodec/me_cmp.o \
libavcodec/simple_idct.o \
libavcodec/avpacket.o \
libavcodec/frame_thread_encoder.o"

    X264_OBJS_amd64="libavcodec/x86/me_cmp.o \
libavcodec/x86/me_cmp_init.o \
libavcodec/x86/constants.o"

    X264_OBJS_armhf="libavcodec/arm/me_cmp_armv6.o \
libavcodec/arm/me_cmp_init_arm.o"

  eval X264_OBJS_machine=\$X264_OBJS_$ARCH

  #echo "gcc $X264_CFLAGS -Wl,-Bsymbolic -o /opt/flussonic/lib/libff_x264.so.1 libavcodec/libx264.c $X264_OBJS -L/opt/flussonic-build/lib -lx264 $X264_LDFLAGS"              
  gcc $X264_CFLAGS -Wl,--version-script=/root/ff_x264.version -Wl,-Bsymbolic -o /opt/flussonic/lib/libff_x264.so.1 \
    libavcodec/libx264.c $X264_OBJS $X264_OBJS_machine -L/opt/flussonic-build/lib -lx264 $X264_LDFLAGS
  cd ..
fi

if [ ! -f /opt/flussonic/lib/libff_x265.so.1 -a "$DISABLE_X265" = 0 ]; then

  echo "GCC libff_x265.so"
  cd ffmpeg-${SRC_VERSION}

  X265_CFLAGS="-I. -I./ -D_ISOC99_SOURCE -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE -D_POSIX_C_SOURCE=200112 \
-D_XOPEN_SOURCE=600 -DPIC -DZLIB_CONST -DHAVE_AV_CONFIG_H -I/opt/flussonic-build/include -std=c99 \
-fomit-frame-pointer -fPIC -O3"
  X265_LDFLAGS="-Wl,--version-script=/root/ff_x265.version \
-Wl,-soname,libff_x264.so.1 -Wl,-Bsymbolic -L/opt/flussonic/lib -lx265 \
-L/opt/flussonic-build/lib -Wl,-rpath /opt/flussonic/lib -Wl,-s -lavcodec -lavutil -lpthread -lm \
-Wl,-Bstatic -lstdc++ -Wl,-Bdynamic"

    X265_OBJS="libavcodec/utils.o \
libavcodec/encode.o \
libavcodec/pthread_frame.o \
libavcodec/pthread.o \
libavcodec/pthread_slice.o \
libavcodec/me_cmp.o \
libavcodec/simple_idct.o \
libavcodec/avpacket.o \
libavcodec/frame_thread_encoder.o"

    X265_OBJS_amd64="libavcodec/x86/me_cmp.o \
libavcodec/x86/me_cmp_init.o \
libavcodec/x86/constants.o"

    X265_OBJS_armhf="libavcodec/arm/me_cmp_armv6.o \
libavcodec/arm/me_cmp_init_arm.o"

  eval X265_OBJS_machine=\$X265_OBJS_$ARCH
  #echo "gcc $X264_CFLAGS -Wl,-Bsymbolic -o /opt/flussonic/lib/libff_x265.so.1 libavcodec/libx265.c $X265_OBJS -L/opt/flussonic-build/lib -lx265 $X264_LDFLAGS"

  [ $DISABLE_X265 = 0 ] && gcc $X265_CFLAGS $X265_OBJS_machine \
    -shared -static-libgcc -o /opt/flussonic/lib/libff_x265.so.1 libavcodec/libx265.c $X265_OBJS $X265_LDFLAGS
  cd ..
fi

fi # SPLITGPL


cd /opt/flussonic
echo "Pack ffmpeg_${ARCH}_${PKG_VERSION}.tgz"
if [ -f bin/ffmpeg ] ; then
  tar zcf "${OUTDIR}/ffmpeg_${ARCH}_${PKG_VERSION}.tgz" bin lib include share
  ls -l "${OUTDIR}/ffmpeg_${ARCH}_${PKG_VERSION}.tgz"
else
  echo 'ERROR build ffmpeg - bin/ffmpeg not found'
fi


