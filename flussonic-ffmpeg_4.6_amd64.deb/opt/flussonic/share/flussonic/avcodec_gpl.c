#include <dlfcn.h>
#include <libavcodec/avcodec.h>
#include "avcodec_gpl.h"

void avcodec_register_gpl(void) {
  void *h;
  AVCodec *codec = NULL;
  if(!avcodec_find_encoder_by_name("libx264")) {
    if((h = dlopen("libff_x264.so.1", RTLD_LAZY)) != NULL) {
      if((codec = (AVCodec*)dlsym(h, "ff_libx264_encoder")) != NULL) {
        av_log(NULL, AV_LOG_WARNING, "Register GPL codec libx264\n");
        avcodec_register(codec);
      }
    } else {
        av_log(NULL, AV_LOG_VERBOSE, "dlerror: %s\n", dlerror());
    }
  }
  if(!avcodec_find_encoder_by_name("libx265")) {
    if((h = dlopen("libff_x265.so.1", RTLD_LAZY)) != NULL) {
      if((codec = (AVCodec*)dlsym(h, "ff_libx265_encoder")) != NULL) {
        av_log(NULL, AV_LOG_WARNING, "Register GPL codec libx265\n");
        avcodec_register(codec);
      }
    } else {
        av_log(NULL, AV_LOG_VERBOSE, "dlerror: %s\n", dlerror());
    }
  }
}
