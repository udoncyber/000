#ifndef FFMPEG_AVCODEC_GPL_H
#define FFMPEG_AVCODEC_GPL_H

void avcodec_register_gpl(void);

#endif
